<?php
defined('BASEPATH') OR exit('No direct script access allowed');


//Setting Currennt Date untuk lokasi di indonesia
class Api extends CI_Controller {
    function __construct(){
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');
        error_reporting(E_ALL);
        ini_set('display_errors',1);
    }

    function search(){
      $produk = $this->input->post('produk');

      $sql = "SELECT * FROM tb_produk WHERE nama LIKE '%$produk%'";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
            $status = true;
            $respon = 200;
            $message = "Data dapat";
            $result = $query->result();
        } else {
            $status = false;
            $respon = 200;
            $message = "Data tidak dapat";
            $result = null;
        }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);

    }

    function login(){
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));

      if (!empty($username) || !empty($password)) {

        $sql = "SELECT * 
        FROM tb_user 
        WHERE username = '$username' 
        AND password = '$password'";
        $query = $this->db->query($sql);

        if ($query->num_rows() > 0) {
            $status = true;
            $respon = 200;
            $message = "Berhasil login";
            $result = $query->row();
        } else {
            $status = false;
            $respon = 200;
            $message = "Gagal login, Username atau password salah";
            $result = null;
        }
        
      } else {
        $status = false;
        $respon = 200;
        $message = "Username dan password harus diisi";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);

    }

    function register(){
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $fullname = $this->input->post('fullname');
      $nohp = $this->input->post('nohp');
      $alamat = $this->input->post('alamat');

    
        $sql = "INSERT INTO tb_user (username, password, fullname, nohp, alamat) VALUES
                ('$username','$password','$fullname','$nohp','$alamat')";

        $query = $this->db->query($sql);
        $show = $this->db->query("SELECT * FROM tb_user WHERE username = '$username'");

        if ($query) {
          $status = true;
          $respon = 200;
          $message = "Berhasil register";
          $result = $show->row();
        } else {
          $status = false;
          $respon = 200;
          $message = "Gagal register";
          $result = null;
        }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);

    }

    function getProduk(){
      $sql = "SELECT A.*, B.kategori FROM tb_produk A, tb_kategori B
              WHERE A.id_kategori = B.id ORDER BY A.created_at DESC";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
        $status = true;
        $respon = 200;
        $message = "Data berhasil didapatkan";
        $result = $query->result();
      } else {
        $status = false;
        $respon = 200;
        $message = "Produk tidak ada";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);
      
    }

    function getProdukPromo(){
      $sql = "SELECT A.*, B.kategori FROM tb_produk A, tb_kategori B
              WHERE A.id_kategori = B.id AND A.promo = 1 ORDER BY A.created_at DESC";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
        $status = true;
        $respon = 200;
        $message = "Data berhasil didapatkan";
        $result = $query->result();
      } else {
        $status = false;
        $respon = 200;
        $message = "Produk promo tidak ada";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);
      
    }

    function getProdukByKategori(){
      $id_kategori = $this->input->post('id_kategori');

      $sql = "SELECT A.*, B.kategori FROM tb_produk A, tb_kategori B
              WHERE A.id_kategori = B.id AND A.id_kategori = '$id_kategori' ORDER BY A.created_at DESC";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
        $status = true;
        $respon = 200;
        $message = "Data berhasil didapatkan";
        $result = $query->result();
      } else {
        $status = false;
        $respon = 200;
        $message = "Produk tidak ada";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);
      
    }

    function getKategori(){
      $sql = "SELECT * FROM tb_kategori";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
        $status = true;
        $respon = 200;
        $message = "Data berhasil didapatkan";
        $result = $query->result();
      } else {
        $status = false;
        $respon = 200;
        $message = "Data tidak ada";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);
      
    }

    function getKeranjang(){
      $sql = "SELECT A.*, B.nama, C.kategori, B.harga, B.gambar
       FROM tb_keranjang A, tb_produk B, tb_kategori C
       WHERE A.id_produk = B.id AND B.id_kategori = C.id ORDER BY A.created_at DESC";
      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
        $status = true;
        $respon = 200;
        $message = "Data berhasil didapatkan";
        $result = $query->result();
      } else {
        $status = false;
        $respon = 200;
        $message = "Data tidak ada";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);
      
    }

    function deleteKeranjang(){
      $id = $this->input->post('id');

      $sql = "DELETE FROM tb_keranjang WHERE id = '$id'";

      $query = $this->db->query($sql);

      if ($query) {
        $status = true;
        $respon = 200;
        $message = "Delete keranjang berhasil";
        $result = null;
      } else {
        $status = false;
        $respon = 200;
        $message = "Gagal delete keranjang";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);


    }



    function addKeranjang(){
      $iduser = $this->input->post('iduser');
      $idproduk = $this->input->post('idproduk');

      $sql = "INSERT INTO tb_keranjang (id_user,id_produk,jumlah)
              VALUES ('$iduser','$idproduk','1')";

      $show = "SELECT * FROM tb_produk
               WHERE id = '$idproduk'";

      $query = $this->db->query($sql);
      $queryshow = $this->db->query($show);

      if ($query) {
        $status = true;
        $respon = 200;
        $message = "Add keranjang berhasil";
        $result = $queryshow->row();
      } else {
        $status = false;
        $respon = 200;
        $message = "Gagal add keranjang";
        $result = null;
      }

      $data['status'] = $status;
      $data['respon'] = $respon;
      $data['message'] = $message;
      $data['data'] = $result;

      echo json_encode($data);


    }
  }